# CLAUDE.md — Kali Pentest MCP Server

## What This Server Does

Exposes Kali Linux penetration testing tools as MCP tools that Claude can call.
Each tool wraps a real CLI binary inside the Docker container, sanitizes inputs,
and returns formatted text output.

## Tools and Their Signatures

| Tool | Key Parameters | Default Flags |
|---|---|---|
| `nmap_scan` | target, flags | `-sV -sC --open` |
| `nikto_scan` | target, extra_flags | (none) |
| `sqlmap_scan` | target, extra_flags | `--batch --level=1 --risk=1` |
| `wpscan_scan` | target, extra_flags | `--enumerate u,vp` |
| `dirb_scan` | target, wordlist, extra_flags | common.txt |
| `searchsploit_query` | search_term, flags | (none) |
| `whois_lookup` | target | — |
| `dns_lookup` | target, record_type | ANY |
| `run_custom_command` | tool, args | — |

## Input Sanitization

`sanitize_target()` in `kali_pentest_server.py` strips whitespace and blocks
these characters: `;  &  |  \`  $  (  )  {  }  <  >  \n  \r`

All CLI args are split with `shlex.split()` — never passed to `shell=True`.

## Adding a New Tool

1. Add the binary to the `apt-get install` list in `Dockerfile`
2. Add a new `@mcp.tool()` function in `kali_pentest_server.py`
   - Single-line docstring only
   - All params default to `""`
   - Return a string
   - Call `run_tool([...])` with a list, never a string + shell=True
3. Add the tool name to the `tools:` list in `custom.yaml`
4. If it should be callable via `run_custom_command`, add it to `ALLOWED_TOOLS`
5. Rebuild: `docker build -t kali-pentest-mcp-server .`

## Timeouts

Default: 120 seconds per command. Long scans (nikto, dirb, wpscan) may need
more. Increase via `CMD_TIMEOUT` environment variable in the catalog YAML or
pass a custom `timeout` to `run_tool()`.

## Output Truncation

Output is capped at `MAX_OUTPUT_CHARS` (default 8000). For full output, either
increase this env var or write results to a file inside the container and read
it back with a separate tool call.

## Known Limitations

- No persistent state between tool calls (each call is a fresh subprocess)
- WPScan API token not required but improves vulnerability detection; set
  `WPSCAN_API_TOKEN` env var if you have one
- searchsploit database is the version bundled in the image; it won't
  auto-update unless you add `searchsploit -u` to the Dockerfile

## MCP Protocol Notes (FastMCP rules followed)

- No `@mcp.prompt()` decorators
- No `prompt=` parameter to `FastMCP()`
- No `Optional`, `Union`, `List` type hints from `typing` module
- All parameters default to `""` (empty string), never `None`
- All tools return `str`
- All docstrings are single-line
